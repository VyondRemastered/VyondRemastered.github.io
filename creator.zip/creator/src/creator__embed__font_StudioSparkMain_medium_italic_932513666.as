package
{
   import mx.core.FontAsset;
   
   [Embed(source="/_assets/158_creator__embed__font_StudioSparkMain_medium_italic_932513666.cff",
   fontName="StudioSparkMain",
   mimeType="application/x-font",
   fontWeight="normal",
   fontStyle="italic",
   embedAsCFF="true"
   )]
   public class creator__embed__font_StudioSparkMain_medium_italic_932513666 extends FontAsset
   {
      
      public function creator__embed__font_StudioSparkMain_medium_italic_932513666()
      {
         super();
      }
   }
}

