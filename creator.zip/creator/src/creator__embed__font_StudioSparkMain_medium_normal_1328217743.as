package
{
   import mx.core.FontAsset;
   
   [Embed(source="/_assets/95_creator__embed__font_StudioSparkMain_medium_normal_1328217743.cff",
   fontName="StudioSparkMain",
   mimeType="application/x-font",
   fontWeight="normal",
   fontStyle="normal",
   embedAsCFF="true"
   )]
   public class creator__embed__font_StudioSparkMain_medium_normal_1328217743 extends FontAsset
   {
      
      public function creator__embed__font_StudioSparkMain_medium_normal_1328217743()
      {
         super();
      }
   }
}

