package
{
   import mx.core.SpriteAsset;
   
   [Embed(source="/_assets/assets.swf", symbol="symbol9")]
   public class _class_embed_css_Assets_swf_1135953132_mx_skins_cursor_DragLink_535912526 extends SpriteAsset
   {
      
      public function _class_embed_css_Assets_swf_1135953132_mx_skins_cursor_DragLink_535912526()
      {
         super();
      }
   }
}

