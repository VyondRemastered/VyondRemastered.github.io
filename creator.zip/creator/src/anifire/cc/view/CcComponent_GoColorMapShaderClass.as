package anifire.cc.view
{
   import mx.core.ByteArrayAsset;
   
   [Embed(source="/_assets/36.bin", mimeType="application/octet-stream")]
   public class CcComponent_GoColorMapShaderClass extends ByteArrayAsset
   {
      
      public function CcComponent_GoColorMapShaderClass()
      {
         super();
      }
   }
}

