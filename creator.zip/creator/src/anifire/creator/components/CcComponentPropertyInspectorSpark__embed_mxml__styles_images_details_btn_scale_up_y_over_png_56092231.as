package anifire.creator.components
{
   import mx.core.BitmapAsset;
   
   [Embed(source="/_assets/34_anifire.creator.components.CcComponentPropertyInspectorSpark__embed_mxml__styles_images_details_btn_scale_up_y_over_png_56092231.png")]
   public class CcComponentPropertyInspectorSpark__embed_mxml__styles_images_details_btn_scale_up_y_over_png_56092231 extends BitmapAsset
   {
      
      public function CcComponentPropertyInspectorSpark__embed_mxml__styles_images_details_btn_scale_up_y_over_png_56092231()
      {
         super();
      }
   }
}

