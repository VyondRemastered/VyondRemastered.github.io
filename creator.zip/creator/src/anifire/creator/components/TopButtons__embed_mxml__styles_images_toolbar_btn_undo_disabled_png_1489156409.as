package anifire.creator.components
{
   import mx.core.BitmapAsset;
   
   [Embed(source="/_assets/92_anifire.creator.components.TopButtons__embed_mxml__styles_images_toolbar_btn_undo_disabled_png_1489156409.png")]
   public class TopButtons__embed_mxml__styles_images_toolbar_btn_undo_disabled_png_1489156409 extends BitmapAsset
   {
      
      public function TopButtons__embed_mxml__styles_images_toolbar_btn_undo_disabled_png_1489156409()
      {
         super();
      }
   }
}

