package anifire.managers
{
   import anifire.component.EyeDropperScreenOverlay;
   
   public class ColorUtils
   {
      
      public static var eyeDropperScreenOverlay:EyeDropperScreenOverlay;
      
      public function ColorUtils()
      {
         super();
      }
      
      public static function colorToHex(param1:uint, param2:String = "") : String
      {
         var _loc3_:uint = uint(0x0F000000 | param1 & 0xFFFFFF);
         var _loc4_:String = _loc3_.toString(16);
         return param2 + _loc4_.substring(1).toUpperCase();
      }
      
      public static function rgbToColor(param1:int, param2:int, param3:int) : uint
      {
         return param1 << 16 | param2 << 8 | param3;
      }
      
      public static function colorToRgb(param1:uint) : Array
      {
         var _loc2_:Array = [];
         _loc2_.push(param1 >> 16 & 0xFF);
         _loc2_.push(param1 >> 8 & 0xFF);
         _loc2_.push(param1 & 0xFF);
         return _loc2_;
      }
   }
}

