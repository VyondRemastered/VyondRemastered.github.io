package anifire.managers
{
   import mx.core.BitmapAsset;
   
   [Embed(source="/_assets/155_anifire.managers.NativeCursorManager_imgCursor4.png")]
   public class NativeCursorManager_imgCursor4 extends BitmapAsset
   {
      
      public function NativeCursorManager_imgCursor4()
      {
         super();
      }
   }
}

