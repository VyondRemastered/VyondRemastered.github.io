package anifire.managers
{
   import mx.core.BitmapAsset;
   
   [Embed(source="/_assets/152_anifire.managers.NativeCursorManager_imgCursor1.png")]
   public class NativeCursorManager_imgCursor1 extends BitmapAsset
   {
      
      public function NativeCursorManager_imgCursor1()
      {
         super();
      }
   }
}

