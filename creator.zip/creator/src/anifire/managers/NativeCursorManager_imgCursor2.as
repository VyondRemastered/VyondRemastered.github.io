package anifire.managers
{
   import mx.core.BitmapAsset;
   
   [Embed(source="/_assets/157_anifire.managers.NativeCursorManager_imgCursor2.png")]
   public class NativeCursorManager_imgCursor2 extends BitmapAsset
   {
      
      public function NativeCursorManager_imgCursor2()
      {
         super();
      }
   }
}

