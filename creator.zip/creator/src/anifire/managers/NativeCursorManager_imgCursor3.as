package anifire.managers
{
   import mx.core.BitmapAsset;
   
   [Embed(source="/_assets/156_anifire.managers.NativeCursorManager_imgCursor3.png")]
   public class NativeCursorManager_imgCursor3 extends BitmapAsset
   {
      
      public function NativeCursorManager_imgCursor3()
      {
         super();
      }
   }
}

