package anifire.component
{
   import mx.core.ByteArrayAsset;
   
   [Embed(source="/_assets/36.bin", mimeType="application/octet-stream")]
   public class CustomCharacterMaker_GoColorMapShaderClass extends ByteArrayAsset
   {
      
      public function CustomCharacterMaker_GoColorMapShaderClass()
      {
         super();
      }
   }
}

