package anifire.skins
{
   import mx.core.BitmapAsset;
   
   [Embed(source="/_assets/90.png")]
   public class ColorInputPanelSkin__embed_mxml__styles_images_colorpalette_slider_control_png_381158866 extends BitmapAsset
   {
      
      public function ColorInputPanelSkin__embed_mxml__styles_images_colorpalette_slider_control_png_381158866()
      {
         super();
      }
   }
}

