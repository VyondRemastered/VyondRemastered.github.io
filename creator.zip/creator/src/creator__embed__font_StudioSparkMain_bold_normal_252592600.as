package
{
   import mx.core.FontAsset;
   
   [Embed(source="/_assets/120_creator__embed__font_StudioSparkMain_bold_normal_252592600.cff",
   fontName="StudioSparkMain",
   mimeType="application/x-font",
   fontWeight="bold",
   fontStyle="normal",
   embedAsCFF="true"
   )]
   public class creator__embed__font_StudioSparkMain_bold_normal_252592600 extends FontAsset
   {
      
      public function creator__embed__font_StudioSparkMain_bold_normal_252592600()
      {
         super();
      }
   }
}

